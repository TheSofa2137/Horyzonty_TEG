import sys

# ── Windows compatibility ─────────────────────────────────────────────────────
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

"""
tools.py — I/O helpers for Neo4j, Amadeus, OpenWeatherMap and on-demand graph enrichment.

Public API used by orchestrator.py:
    city_exists_in_graph, city_has_neighbourhoods, enrich_city_in_graph,
    search_flights, search_hotels, get_weather
"""

import json
import os
import random
import time
import requests as http_requests
from datetime import date, timedelta
from dotenv import load_dotenv
from neo4j import GraphDatabase
from langchain_ollama import ChatOllama

load_dotenv()

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PW = "12345678"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PW))
llm = ChatOllama(model="llama3.2:3b")


def city_exists_in_graph(city: str) -> bool:
    """Checks whether the city already exists in the Neo4j graph."""
    with driver.session() as session:
        result = session.run(
            "MATCH (c:City {name: $city}) RETURN count(c) as count",
            city=city
        )
        record = result.single()
        return bool(record and record["count"] > 0)


def city_has_neighbourhoods(city: str) -> bool:
    """Checks whether the city already has neighbourhoods in the graph."""
    with driver.session() as session:
        result = session.run(
            "MATCH (nb:Neighbourhood)-[:PART_OF]->(c:City {name: $city}) RETURN count(nb) as count",
            city=city
        )
        record = result.single()
        return bool(record and record["count"] > 0)


def _generate_city_data_via_llm(city: str) -> dict:
    """
    Asks the LLM to produce structured travel data for *city*.
    Raises an exception (caught by the caller) when the response is not valid JSON.
    """
    prompt = f"""Generate complete travel data for the CITY: {city}

⚠️ IMPORTANT DISAMBIGUATION:
- "{city}" refers to the CITY named {city} (a standalone travel destination with its own airport/transport hub)
- Do NOT confuse it with any district or neighbourhood of another city
- For example: "Praga" = Prague (capital of Czech Republic), NOT Praga district of Warsaw
- Generate data appropriate for a CITY-LEVEL travel destination

Return ONLY a valid JSON object (no markdown) in this EXACT format:
{{
  "neighbourhoods": [
    {{"name": "Old Town", "description": "Historic center with main attractions", "near_to": ["City Center"]}},
    {{"name": "City Center", "description": "Modern shopping and business area", "near_to": ["Old Town"]}}
  ],
  "attractions": [
    {{"name": "Main Cathedral", "category": "church", "free": true, "cost": 0,
      "open_days": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
      "neighbourhood": "Old Town", "description": "Historic cathedral from 12th century"}},
    {{"name": "City Museum", "category": "museum", "free": false, "cost": 12,
      "open_days": ["Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
      "neighbourhood": "Old Town", "description": "Main city museum with history exhibits"}}
  ],
  "hotels": [
    {{"name": "Hotel Name", "price": 200}},
    {{"name": "Budget Inn", "price": 120}}
  ],
  "flights": [
    {{"airline": "LOT Polish Airlines", "price": 450}},
    {{"airline": "Ryanair", "price": 280}}
  ]
}}

Rules for {city}:
- Include 3-5 REAL neighbourhoods of the CITY {city} (use actual district names of THIS city)
- Include 8-12 REAL attractions that are located IN THE CITY {city}
- category must be ONE of: gallery, museum, monument, church, park, viewpoint, landmark, attraction
- open_days: array of day names in English (Monday, Tuesday, etc.)
- near_to: list of neighbouring district names from the same list
- free: boolean (true if free entry)
- cost: integer in PLN (0 if free)
- neighbourhood: must match one of the neighbourhood names above
- Include 2-3 hotels (prices 100-500 PLN/night)
- Include 2-3 flights from Warsaw (prices 200-900 PLN)
- Return ONLY the JSON, no explanation"""

    response = llm.invoke(prompt)
    raw = response.content.strip()
    if "```json" in raw:
        raw = raw.split("```json")[1].split("```")[0].strip()
    elif "```" in raw:
        raw = raw.split("```")[1].split("```")[0].strip()
    return json.loads(raw)


def _fallback_city_data(city: str) -> dict:
    """Returns minimal placeholder data used when LLM generation fails."""
    return {
        "neighbourhoods": [
            {"name": f"{city} Old Town", "description": "Historic city centre", "near_to": [f"{city} Center"]},
            {"name": f"{city} Center",   "description": "Modern city centre",   "near_to": [f"{city} Old Town"]},
        ],
        "attractions": [
            {"name": f"{city} Cathedral",     "category": "church",   "free": True,  "cost": 0,
             "open_days": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
             "neighbourhood": f"{city} Old Town", "description": "Main cathedral"},
            {"name": f"{city} Main Museum",   "category": "museum",   "free": False, "cost": 12,
             "open_days": ["Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
             "neighbourhood": f"{city} Old Town", "description": "City history museum"},
            {"name": f"{city} Central Park",  "category": "park",     "free": True,  "cost": 0,
             "open_days": ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
             "neighbourhood": f"{city} Center", "description": "Main city park"},
            {"name": f"{city} Art Gallery",   "category": "gallery",  "free": True,  "cost": 0,
             "open_days": ["Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
             "neighbourhood": f"{city} Center", "description": "Contemporary art gallery"},
            {"name": f"{city} Historic Castle","category": "monument","free": False, "cost": 10,
             "open_days": ["Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"],
             "neighbourhood": f"{city} Old Town", "description": "Historic castle"},
        ],
        "hotels": [
            {"name": f"Hotel {city} Center", "price": random.randint(150, 250)},
            {"name": f"{city} Budget Inn",   "price": random.randint(80, 150)},
        ],
        "flights": [
            {"airline": "LOT Polish Airlines", "price": random.randint(300, 600)},
            {"airline": "Ryanair",             "price": random.randint(150, 400)},
        ],
    }


def _persist_city_to_graph(city: str, data: dict) -> tuple[int, int]:
    """
    Writes all city data (neighbourhoods, attractions, hotels, flights) to Neo4j.
    Returns (neighbourhood_count, attraction_count).
    """
    with driver.session() as session:
        session.run("MERGE (c:City {name: $city})", city=city)

        for nb in data.get("neighbourhoods", []):
            session.run("""
                MATCH (c:City {name: $city})
                MERGE (nb:Neighbourhood {name: $name})
                SET nb.description = $description
                MERGE (nb)-[:PART_OF]->(c)
            """, city=city, name=nb["name"], description=nb.get("description", ""))

        for nb in data.get("neighbourhoods", []):
            for near in nb.get("near_to", []):
                session.run("""
                    MATCH (a:Neighbourhood {name: $a}), (b:Neighbourhood {name: $b})
                    MERGE (a)-[:NEAR_TO]->(b)
                    MERGE (b)-[:NEAR_TO]->(a)
                """, a=nb["name"], b=near)

        for attr in data.get("attractions", []):
            nb_name = attr.get("neighbourhood", "")
            session.run("""
                MATCH (c:City {name: $city})
                MERGE (a:Attraction {name: $name})
                SET a.category    = $category,
                    a.free        = $free,
                    a.cost        = $cost,
                    a.open_days   = $open_days,
                    a.description = $description
                MERGE (a)-[:LOCATED_IN]->(c)
            """, city=city, name=attr["name"], category=attr.get("category", "attraction"),
                       free=bool(attr.get("free", False)), cost=int(attr.get("cost", 0)),
                       open_days=attr.get("open_days", []), description=attr.get("description", ""))
            if nb_name:
                session.run("""
                    MATCH (a:Attraction {name: $name})
                    MATCH (nb:Neighbourhood {name: $nb})
                    MERGE (a)-[:LOCATED_IN]->(nb)
                """, name=attr["name"], nb=nb_name)

        for hotel in data.get("hotels", []):
            session.run("""
                MATCH (c:City {name: $city})
                MERGE (h:Hotel {name: $name, price: $price})
                MERGE (h)-[:LOCATED_IN]->(c)
            """, city=city, name=hotel["name"], price=float(hotel.get("price", 200)))

        for flight in data.get("flights", []):
            session.run("""
                MATCH (c:City {name: $city})
                MERGE (f:Flight {origin: 'WAW', airline: $airline, price: $price, date: '2026-06-15'})
                MERGE (f)-[:FLIES_TO]->(c)
            """, city=city, airline=flight["airline"], price=float(flight.get("price", 400)))

    return len(data.get("neighbourhoods", [])), len(data.get("attractions", []))


def enrich_city_in_graph(city: str) -> dict:
    """
    Populates Neo4j with LLM-generated travel data for an unknown city.
    Falls back to minimal placeholder data when the LLM response cannot be parsed.
    """
    print(f"🌍 [Graph Enrichment] Generating data for '{city}'...")
    try:
        data = _generate_city_data_via_llm(city)
        print(f"  ✅ LLM generated: {len(data.get('neighbourhoods', []))} neighbourhoods, "
              f"{len(data.get('attractions', []))} attractions")
    except Exception as e:
        print(f"  ⚠️ LLM parse error ({e}). Using fallback data.")
        data = _fallback_city_data(city)

    nb_count, attr_count = _persist_city_to_graph(city, data)
    print(f"  🗄️ Saved to Neo4j: {nb_count} neighbourhoods, {attr_count} attractions, hotels, flights")
    return data


CITY_TO_IATA: dict[str, str] = {
    "Lisbon": "LIS", "Porto": "OPO", "Barcelona": "BCN",
    "Prague": "PRG", "Vienna": "VIE", "Rome": "FCO",
    "Milan": "MXP", "Florence": "FLR", "Paris": "CDG",
    "Amsterdam": "AMS", "Krakow": "KRK", "Warsaw": "WAW",
    "London": "LHR", "Madrid": "MAD", "Athens": "ATH",
    "Istanbul": "IST", "Budapest": "BUD", "Berlin": "BER",
    "Munich": "MUC", "Edinburgh": "EDI", "Dubrovnik": "DBV",
    "Brussels": "BRU", "Copenhagen": "CPH", "Stockholm": "ARN",
    "Oslo": "OSL", "Helsinki": "HEL", "Zurich": "ZRH",
    "Geneva": "GVA", "Venice": "VCE", "Naples": "NAP",
    "Seville": "SVQ", "Valencia": "VLC", "Nice": "NCE",
    "Lyon": "LYS", "Marseille": "MRS", "Riga": "RIX",
    "Tallinn": "TLL", "Vilnius": "VNO", "Bratislava": "BTS",
    "Ljubljana": "LJU", "Zagreb": "ZAG", "Bucharest": "OTP",
    "Sofia": "SOF", "Belgrade": "BEG", "Reykjavik": "KEF",
    "Dubai": "DXB", "Cairo": "CAI",
    "Tokyo": "NRT", "Bangkok": "BKK", "Singapore": "SIN",
    "New York": "JFK", "Miami": "MIA", "Los Angeles": "LAX",
}

CARRIER_NAMES: dict[str, str] = {
    "FR": "Ryanair", "LO": "LOT Polish Airlines", "TP": "TAP Portugal",
    "VY": "Vueling", "W6": "Wizz Air", "U2": "easyJet",
    "OS": "Austrian Airlines", "LH": "Lufthansa", "AF": "Air France",
    "KL": "KLM", "BA": "British Airways", "IB": "Iberia",
    "AZ": "Alitalia / ITA", "SK": "SAS", "FI": "Icelandair",
    "EK": "Emirates", "QR": "Qatar Airways", "TK": "Turkish Airlines",
    "AY": "Finnair", "SN": "Brussels Airlines",
}

BOOKING_URLS: dict[str, str] = {
    "Ryanair":             "https://www.ryanair.com/gb/en/cheap-flights",
    "LOT Polish Airlines": "https://www.lot.com/pl/en",
    "TAP Portugal":        "https://www.flytap.com/en-gb",
    "Vueling":             "https://www.vueling.com/en",
    "Wizz Air":            "https://wizzair.com",
    "easyJet":             "https://www.easyjet.com/en",
    "Austrian Airlines":   "https://www.austrian.com/global/en",
    "Lufthansa":           "https://www.lufthansa.com/gb/en",
    "Air France":          "https://www.airfrance.com",
    "KLM":                 "https://www.klm.com/en",
    "British Airways":     "https://www.britishairways.com/en-gb",
    "Iberia":              "https://www.iberia.com/web/portal",
    "Alitalia / ITA":      "https://www.ita-airways.com/en_gb",
    "SAS":                 "https://www.flysas.com/en",
    "Icelandair":          "https://www.icelandair.com",
    "Emirates":            "https://www.emirates.com/english",
    "Qatar Airways":       "https://www.qatarairways.com/en",
    "Turkish Airlines":    "https://www.turkishairlines.com",
    "Finnair":             "https://www.finnair.com/en",
    "Brussels Airlines":   "https://www.brusselsairlines.com/en",
}


def _booking_url_for(airline: str) -> str:
    """Returns a direct booking URL for the given airline, or a Google Flights fallback."""
    return BOOKING_URLS.get(airline, f"https://www.google.com/flights#search;q={airline.replace(' ', '+')}")


_amadeus_cache: dict = {"token": None, "expires_at": 0.0}
AMADEUS_BASE = "https://test.api.amadeus.com"


def _get_amadeus_token() -> str | None:
    """Returns a valid Amadeus OAuth2 Bearer token, refreshing if needed."""
    client_id = os.environ.get("AMADEUS_API_KEY", "")
    client_secret = os.environ.get("AMADEUS_API_SECRET", "")
    if not client_id or not client_secret:
        return None

    now = time.time()
    if _amadeus_cache["token"] and now < _amadeus_cache["expires_at"] - 30:
        return _amadeus_cache["token"]

    try:
        resp = http_requests.post(
            f"{AMADEUS_BASE}/v1/security/oauth2/token",
            data={"grant_type": "client_credentials",
                  "client_id": client_id, "client_secret": client_secret},
            timeout=10,
        )
        if resp.status_code == 200:
            data = resp.json()
            _amadeus_cache["token"] = data["access_token"]
            _amadeus_cache["expires_at"] = now + data.get("expires_in", 1700)
            print("  🔑 Amadeus token refreshed")
            return _amadeus_cache["token"]
        else:
            print(f"  ⚠️ Amadeus auth failed: {resp.status_code} — {resp.text[:120]}")
    except Exception as e:
        print(f"  ⚠️ Amadeus auth error: {e}")
    return None


def search_flights_amadeus(city: str, origin: str = "WAW",
                           departure_date: str = None) -> list:
    """
    Searches live flight offers via Amadeus Flight Offers Search API.
    Returns [] if Amadeus is unavailable or city has no IATA mapping.
    """
    dest_iata = CITY_TO_IATA.get(city)
    if not dest_iata:
        print(f"  ⚠️ No IATA code for '{city}' — skipping Amadeus flights")
        return []

    dep_date = departure_date or (date.today() + timedelta(days=30)).isoformat()
    token = _get_amadeus_token()
    if not token:
        print("  ⚠️ No Amadeus credentials — skipping Amadeus flights")
        return []

    try:
        resp = http_requests.get(
            f"{AMADEUS_BASE}/v2/shopping/flight-offers",
            headers={"Authorization": f"Bearer {token}"},
            params={
                "originLocationCode": origin,
                "destinationLocationCode": dest_iata,
                "departureDate": dep_date,
                "adults": 1,
                "max": 6,
                "currencyCode": "PLN",
            },
            timeout=15,
        )
        if resp.status_code != 200:
            print(f"  ⚠️ Amadeus flight search {resp.status_code}: {resp.text[:120]}")
            return []

        body = resp.json()
        offers = body.get("data", [])
        carriers = body.get("dictionaries", {}).get("carriers", {})
        flights = []

        for offer in offers[:5]:
            try:
                price = round(float(offer["price"]["grandTotal"]))
                currency = offer["price"].get("currency", "PLN")
                carrier_code = (offer.get("validatingAirlineCodes") or ["??"])[0]
                airline = CARRIER_NAMES.get(carrier_code) or carriers.get(carrier_code, carrier_code)

                seg = offer["itineraries"][0]["segments"][0]
                dep_time = seg["departure"]["at"][11:16]
                arr_time = seg["arrival"]["at"][11:16]
                raw_dur = offer["itineraries"][0].get("duration", "")
                duration = raw_dur.replace("PT", "").replace("H", "h ").replace("M", "m").strip()

                flights.append({
                    "airline": airline,
                    "price": price,
                    "currency": currency,
                    "departure": dep_time,
                    "arrival": arr_time,
                    "duration": duration,
                    "date": dep_date,
                    "source": "Amadeus",
                    "booking_url": _booking_url_for(airline),
                })
            except (KeyError, IndexError, ValueError):
                continue

        flights.sort(key=lambda x: x["price"])
        print(f"  ✈️ Amadeus: {len(flights)} flights {origin}→{dest_iata} on {dep_date}")
        return flights

    except Exception as e:
        print(f"  ⚠️ Amadeus flight search exception: {e}")
        return []


def search_flights(city: str, departure_date: str = None):
    """Tries Amadeus live data first, falls back to Neo4j seed data."""
    print(f"🛠️ Tool 'search_flights' called for city: {city}, date: {departure_date}")

    amadeus_flights = search_flights_amadeus(city, departure_date=departure_date)
    if amadeus_flights:
        return amadeus_flights

    print(f"  📋 Amadeus returned no data — falling back to Neo4j for {city}")
    with driver.session() as session:
        result = session.run("""
            MATCH (f:Flight)-[:FLIES_TO]->(c:City {name: $city})
            WHERE f.price IS NOT NULL
            RETURN f.airline as airline, f.price as price
            ORDER BY f.price ASC
        """, city=city)
        flights = [
            {
                "airline": record["airline"],
                "price": record["price"],
                "booking_url": _booking_url_for(record["airline"]),
            }
            for record in result
        ]
        print(f"  ✈️ Neo4j flights found: {len(flights)}")
        return flights


def search_hotels(city: str):
    """Returns hotels in the given city from Neo4j, ordered by price."""
    print(f"🛠️ Tool 'search_hotels' called for city: {city}")
    with driver.session() as session:
        result = session.run("""
            MATCH (h:Hotel)-[:LOCATED_IN]->(c:City {name: $city})
            WHERE h.price IS NOT NULL
            RETURN h.name as name, h.price as price
            ORDER BY h.price ASC
        """, city=city)
        hotels = [{"name": record["name"], "price": record["price"]} for record in result]
        print(f"  🏨 Hotels found: {len(hotels)}")
        return hotels


def _rain_level(rain_probability: int) -> str:
    """Maps rain probability (0–100) to outdoor suitability level."""
    if rain_probability < 20:
        return "perfect"
    elif rain_probability < 40:
        return "good"
    elif rain_probability < 70:
        return "mixed"
    else:
        return "rainy"


def _mock_weather(city: str, days: int, reason: str = "no API key") -> dict:
    """Returns a plausible simulated forecast when the API key is absent."""
    conditions = [
        ("sunny",          10),
        ("partly cloudy",  30),
        ("cloudy",         55),
        ("light rain",     65),
        ("heavy rain",     85),
    ]
    today = date.today()
    forecast = []
    for i in range(days):
        desc, rain = random.choice(conditions)
        forecast.append({
            "date": (today + timedelta(days=i)).isoformat(),
            "temp_avg": random.randint(14, 26),
            "description": desc,
            "rain_probability": rain,
            "outdoor_level": _rain_level(rain),
            "outdoor_friendly": rain < 70,
        })
    return {"city": city, "forecast": forecast, "source": f"Demo forecast ({reason})"}


def get_weather(city: str, days: int = 5) -> dict:
    """
    Fetches 5-day forecast from OpenWeatherMap (3h slots aggregated to daily).
    Falls back to mock data when OPENWEATHERMAP_API_KEY is not set.
    """
    api_key = os.environ.get("OPENWEATHERMAP_API_KEY", "")
    if not api_key:
        print(f"  ⚠️ OPENWEATHERMAP_API_KEY not set — using demo forecast for '{city}'")
        return _mock_weather(city, days, reason="set OPENWEATHERMAP_API_KEY in .env")

    try:
        cnt = min(days, 5) * 8  # free tier: 5 days × 8 three-hour slots
        params = {"q": city, "appid": api_key, "units": "metric", "cnt": cnt}
        resp = http_requests.get("https://api.openweathermap.org/data/2.5/forecast",
                                 params=params, timeout=10)
        data = resp.json()

        if str(data.get("cod")) != "200":
            msg = data.get("message", "unknown error")
            print(f"  ⚠️ OpenWeatherMap API error: {msg} — using demo forecast")
            reason = ("key not yet activated — new keys take up to 2h"
                      if "Invalid API key" in msg else f"API error: {msg}")
            return _mock_weather(city, days, reason=reason)

        # Aggregate 3-h slots → daily buckets
        daily: dict = {}
        for slot in data["list"]:
            d = slot["dt_txt"][:10]
            if d not in daily:
                daily[d] = {"temps": [], "descriptions": [], "rain_probs": []}
            daily[d]["temps"].append(slot["main"]["temp"])
            daily[d]["descriptions"].append(slot["weather"][0]["description"])
            daily[d]["rain_probs"].append(slot.get("pop", 0))

        forecast = []
        for day_date, info in list(daily.items())[:days]:
            avg_temp = round(sum(info["temps"]) / len(info["temps"]), 1)
            max_rain = max(info["rain_probs"])
            main_desc = max(set(info["descriptions"]), key=info["descriptions"].count)
            forecast.append({
                "date": day_date,
                "temp_avg": avg_temp,
                "description": main_desc,
                "rain_probability": int(float(max_rain) * 100),
                "outdoor_level": _rain_level(int(float(max_rain) * 100)),
                "outdoor_friendly": float(max_rain) < 0.7,
            })

        print(f"  ✅ Weather fetched for '{city}': {len(forecast)} days")
        return {"city": city, "forecast": forecast, "source": "OpenWeatherMap"}

    except Exception as e:
        print(f"  ⚠️ Weather fetch error: {e} — using demo forecast")
        return _mock_weather(city, days, reason=str(e))
