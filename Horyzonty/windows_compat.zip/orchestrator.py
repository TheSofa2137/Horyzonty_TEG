import sys

# ── Windows compatibility ─────────────────────────────────────────────────────
# Must be at the very top — orchestrator.py is imported by api.py, and its
# module-level print() calls (with emoji) execute before api.py's own fix runs.
if sys.platform == "win32" and hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import os
import requests
from neo4j import GraphDatabase
from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_chroma import Chroma
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_classic.retrievers.multi_query import MultiQueryRetriever
from langchain_core.prompts import PromptTemplate
from typing import TypedDict, Annotated, Sequence
import operator
from langchain_core.messages import BaseMessage
from langgraph.graph import StateGraph, END

from tools import (
    search_flights, search_hotels,
    city_exists_in_graph, enrich_city_in_graph, city_has_neighbourhoods,
    get_weather,
)

NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PW = "12345678"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CHROMA_PATH = os.path.join(BASE_DIR, "backend", "chroma_db")

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PW))
embeddings_model = OllamaEmbeddings(model="nomic-embed-text")
llm = ChatOllama(model="llama3.2:3b")
llm_stream = ChatOllama(model="llama3.2:3b", streaming=True)

print("📂 Loading ChromaDB from disk...")
chroma_db = Chroma(persist_directory=CHROMA_PATH, embedding_function=embeddings_model)
print(f"✅ ChromaDB loaded ({chroma_db._collection.count()} chunks)")

_chroma_cities_cache: set[str] = set()

# ── RAG / text-splitting configuration ─────────────────────────────────────
_RAG_K: int = 6           # chunks per base-retriever query (kept small to limit overlap)
_RAG_FETCH_K: int = 12    # candidate pool size for MMR re-ranking per query
_MQR_FINAL_K: int = 12    # max chunks returned after MultiQuery merge
_WIKI_CHUNK_SIZE: int = 800
_WIKI_CHUNK_OVERLAP: int = 100
_MIN_WIKI_CHARS: int = 300   # minimum article length worth chunking

_rag_splitter = RecursiveCharacterTextSplitter(
    chunk_size=_WIKI_CHUNK_SIZE, chunk_overlap=_WIKI_CHUNK_OVERLAP
)

# ── MultiQueryRetriever setup ────────────────────────────────────────────────
# Wraps the ChromaDB MMR retriever with an LLM that generates 3 alternative
# phrasings of every incoming query, retrieving docs for each and deduplicating.
# Result: broader and more diverse RAG coverage than a single MMR pass.

# Strict prompt: llama3.2:3b tends to add "Here are three versions:" prefix text
# and numbered explanations — those lines would be passed as spurious search queries.
_MQR_PROMPT = PromptTemplate(
    input_variables=["question"],
    template="""You are a travel search assistant. Generate exactly 3 alternative search queries.
Output ONLY the 3 queries, one per line. No numbers, no bullets, no explanation.

Question: {question}

Queries:""",
)


def _is_real_query(line: str) -> bool:
    """
    Guards the query list against LLM output pollution.
    Called by _FilteredMultiQueryRetriever.generate_queries() on every line
    the LLM produces before those lines reach ChromaDB.

    Rejects lines that are clearly LLM meta-commentary rather than real queries:
    - Too short (< 8 chars) or too long (> 250 chars, explanatory text)
    - Starts with ordinal / bullet characters (1. 2. 3. * -)
    - Starts with common LLM preamble phrases
    """
    line = line.strip()
    if not line or len(line) < 8 or len(line) > 250:
        return False
    low = line.lower()
    reject_prefixes = (
        "here are", "these are", "these alternative", "these questions",
        "this version", "this question", "alternative", "note:",
        "the following", "below are", "*", "-", "by generating",
        "the above", "each of", "i've generated",
    )
    if any(low.startswith(p) for p in reject_prefixes):
        return False
    # Reject numbered list items: "1. What...", "2) How...", "3: Where..."
    if len(line) > 2 and line[0].isdigit() and line[1] in ".):" :
        return False
    return True


class _FilteredMultiQueryRetriever(MultiQueryRetriever):
    """
    MultiQueryRetriever with post-generation query-line filtering.

    llama3.2:3b sometimes prefixes its output with lines like
    "Here are three alternative versions:" or numbered explanations even with
    a strict prompt.  Overriding generate_queries() applies _is_real_query()
    so those lines never reach the ChromaDB MMR retriever.
    """

    def generate_queries(self, question: str, run_manager) -> list[str]:  # type: ignore[override]
        raw: list[str] = super().generate_queries(question, run_manager)
        filtered = [q for q in raw if _is_real_query(q)]
        if not filtered:
            # Safety net: if everything got filtered, fall back to raw output
            print("  ⚠️  All generated queries filtered out — using raw LLM output")
            return raw
        dropped = len(raw) - len(filtered)
        if dropped:
            print(f"  🔍 MQR: dropped {dropped} non-query line(s) from LLM output")
        return filtered


_base_retriever = chroma_db.as_retriever(
    search_type="mmr",
    search_kwargs={"k": _RAG_K, "fetch_k": _RAG_FETCH_K},
)
_multi_query_retriever = _FilteredMultiQueryRetriever.from_llm(
    retriever=_base_retriever,
    llm=llm,
    prompt=_MQR_PROMPT,
    include_original=True,   # always include the original query too
)

# ── Weather display maps (shared by planner_agent and weather_agent) ────────
_WEATHER_LEVEL_ICON: dict[str, str] = {
    "perfect": "☀️", "good": "🌤️", "mixed": "⛅", "rainy": "🌧️",
}
_WEATHER_LEVEL_HINT: dict[str, str] = {
    "perfect": "",
    "good":    " *(bring an umbrella just in case)*",
    "mixed":   " ⚠️ *Mixed — outdoor in morning, indoor in afternoon recommended*",
    "rainy":   " ⚠️ *High rain — plan indoor activities*",
}
_WEATHER_LEVEL_INSTRUCTION: dict[str, str] = {
    "perfect": "OUTDOOR OK all day — freely schedule parks, viewpoints, outdoor markets",
    "good":    "OUTDOOR OK — schedule outdoor attractions, note guest should bring umbrella",
    "mixed":   "MIXED — schedule outdoor in MORNING only; move afternoon INDOORS (museums, galleries, cafes)",
    "rainy":   "⚠️ INDOOR ONLY — do NOT schedule parks, viewpoints, outdoor walks; use museums, galleries, restaurants",
}

# ── Intent keyword sets ──────────────────────────────────────────────────────
# Evaluated deterministically before the LLM classifier to reduce latency and
# avoid small-model hallucinations on common patterns.
_KW_INJECTION: tuple[str, ...] = (
    "ignore all previous", "ignore previous instructions", "disregard your instructions",
    "forget your instructions", "you are now a", "pretend to be", "act as if you are",
    "reveal your system prompt", "show your system prompt", "what is your system prompt",
    "print your system prompt", "repeat your instructions", "output your instructions",
    "override your", "jailbreak", "dan mode", "developer mode",
    "ignore the above", "disregard the above", "new instructions:",
    "bypass your", "disable your filters", "your real instructions",
    "act as", "roleplay as", "simulate being", "forget everything",
    "reset your instructions", "ignore safety",
)
_KW_NEW_TRIP: tuple[str, ...] = (
    "plan a trip", "plan my trip", "plan trip", "plan a holiday", "plan a vacation",
    "new trip", "new plan", "create a plan", "make a plan", "generate a plan",
    "create itinerary", "make itinerary", "build an itinerary", "itinerary for",
    "organise a trip", "organize a trip", "arrange a trip",
    " days in ", " day in ",
    "trip to ", "holiday in ", "vacation in ", "visit to ",
    "weekend in ", "week in ", "long weekend in ", " week trip",
    "for 1 day", "for 2 day", "for 3 day", "for 4 day", "for 5 day",
    "for 6 day", "for 7 day", "for a week",
    "1 day trip", "2 day trip", "3 day trip", "4 day trip", "5 day trip",
    "1 night", "2 nights", "3 nights", "4 nights", "5 nights",
    "plan for", "schedule for", "suggest a trip", "recommend a trip",
    "i want to go to", "i'd like to go to", "i want to visit",
    "take me to", "going to visit",
)
_KW_JUSTIFY: tuple[str, ...] = (
    "why did you", "why this", "why recommend", "why choose", "why suggest",
    "why did you pick", "why that hotel", "why that flight", "why that attraction",
    "explain why", "explain your choice", "reason for", "what is the reason",
    "how did you decide", "how did you choose", "how did you pick",
    "justify", "source of", "where did you get", "based on what",
    "how do you know", "what source", "show me the source",
    "prove it", "back that up", "cite your source",
)
_KW_GRAPH: tuple[str, ...] = (
    "open on sunday", "open on saturday", "open on monday", "open on tuesday",
    "open on wednesday", "open on thursday", "open on friday",
    "open today", "open tomorrow", "open this weekend", "open at",
    "what's open", "which museums", "which galleries", "which parks",
    "closed on", "opening hours", "opening times", "when does it open",
    "near to", "nearby", "close to", "next to", "walking distance",
    "near the hotel", "close to the hotel", "near my hotel",
    "in the neighbourhood", "in the neighborhood", "in old town",
    "what's nearby", "what is nearby", "places nearby",
    "free museum", "free gallery", "free galleries", "free attractions",
    "free entry", "free admission", "no entry fee", "no admission fee",
    "neighbourhood", "district", "area near", "part of the city",
    "galleries in", "museums in", "museums near", "galleries near",
    "attractions near", "things near",
)
_KW_FLIGHT: tuple[str, ...] = (
    "find flight", "search flight", "show flight", "show flights",
    "cheap flights", "flights to", "fly to", "available flights",
    "flight from", "book a flight", "flight options", "flight deals",
    "how to fly to", "direct flight", "connecting flight",
    "next flight", "what airlines fly", "which airline",
    "departing from", "flying from warsaw", "from waw",
)
_KW_HOTEL: tuple[str, ...] = (
    "find hotel", "search hotel", "show hotel", "show hotels",
    "hotels in", "accommodation", "where to stay", "book a hotel",
    "available hotels", "place to stay",
    "cheapest hotel", "best hotel", "hotel options", "hotel deals",
    "hostel in", "airbnb in", "apartment in", "guesthouse",
    "lodging", "overnight stay", "stay in", "inn ",
    "bed and breakfast", "b&b",
)
_KW_ATTRACTIONS: tuple[str, ...] = (
    "what to see", "what to do", "things to do", "sightseeing",
    "attractions in", "places to visit", "tourist spots", "must see",
    "points of interest", "top sights",
    "what can i see", "what can i do", "what's worth seeing",
    "top attractions", "best places to visit", "best things to do",
    "places to go", "tourist attractions", "sightseeing spots",
    "local attractions", "city highlights", "hidden gems",
    "recommended places", "what should i see", "what should i visit",
    "popular spots", "famous places", "landmarks in",
)
_KW_RECALL: tuple[str, ...] = (
    "what was my", "what is my", "what's my",
    "remind me", "do you remember", "what did you",
    "how much was", "how much is my", "what budget",
    "what city", "what destination", "how many days",
    "what hotel did", "which hotel", "which flight",
    "what airline", "what dates", "when is my trip",
    "what time does", "how long is my", "what was planned",
    "what's in my plan", "what's included", "show my plan",
    "tell me my", "recap my", "summary of my",
)
_KW_REFINE: tuple[str, ...] = (
    "replace ", "remove ", "change ", "swap ", "add ",
    "cheaper", "more expensive", "modify", "update",
    "instead of", "drop ", "skip ", "adjust ",
    "make it cheaper", "make it more expensive",
    "include ", "cut the ", "fix the ", "move ",
    "reschedule", "extend the", "shorten the",
    "switch ", "delete ", "edit ", "revise ",
    "add a day", "remove a day", "different hotel",
    "different flight", "earlier flight", "later flight",
    "upgrade the", "downgrade the",
)
_KW_WEATHER: tuple[str, ...] = (
    "weather", "forecast", "will it rain", "is it sunny", "temperature in",
    "what's the weather", "how's the weather", "rain probability",
    "weather in", "climate", "bring umbrella",
    "hot in", "cold in", "snow in", "rainy season", "dry season",
    "best time to visit", "what to pack", "what to wear",
    "is it warm", "is it cold", "how warm", "how cold",
    "chance of rain", "sunny days", "average temperature",
)
_KW_OFF_TOPIC: tuple[str, ...] = (
    "how to code", "write code", "write a program",
    "calculate ", "what is bitcoin", "tell me a joke",
    "tell me a story", "write an essay", "stock price",
    "recipe for", "how to cook", "who won the", "sports score",
    "translate this", "math problem", "do my homework",
    "medical advice", "symptoms of", "what are the symptoms",
    "diagnose me", "stock market", "crypto price",
)


def city_in_chroma(city: str) -> bool:
    """Check if ChromaDB contains data for the given city."""
    if city in _chroma_cities_cache:
        return True
    results = chroma_db.similarity_search_with_score(city, k=5)
    found = any(city.lower() in doc.page_content.lower() for doc, _ in results)
    if found:
        _chroma_cities_cache.add(city)
    return found


_WIKI_HEADERS = {"User-Agent": "HoryzontyTravelBot/1.0 (travel-assistant)"}


def _fetch_wikivoyage(city: str) -> str:
    """Fetch travel article from Wikivoyage."""
    try:
        resp = requests.get(
            "https://en.wikivoyage.org/w/api.php",
            params={"action": "query", "prop": "extracts", "titles": city,
                    "format": "json", "explaintext": 1, "formatversion": "2"},
            headers=_WIKI_HEADERS,
            timeout=15
        )
        if resp.status_code == 200:
            pages = resp.json().get("query", {}).get("pages", [])
            for page in pages:
                if page.get("pageid", -1) != -1:
                    text = page.get("extract", "")
                    if text and len(text) > _MIN_WIKI_CHARS:
                        return text
    except Exception as e:
        print(f"  ⚠️ Wikivoyage error: {e}")
    return ""


def _fetch_wikipedia_summary(city: str) -> str:
    """Fetch Wikipedia summary as fallback."""
    try:
        resp = requests.get(
            f"https://en.wikipedia.org/api/rest_v1/page/summary/{city.replace(' ', '_')}",
            headers=_WIKI_HEADERS,
            timeout=10
        )
        if resp.status_code == 200:
            return resp.json().get("extract", "")
    except Exception as e:
        print(f"  ⚠️ Wikipedia error: {e}")
    return ""


def ensure_city_in_chroma(city: str):
    """
    If city is NOT in ChromaDB — fetch article from Wikivoyage (fallback: Wikipedia)
    and add it as chunks to ChromaDB. Called automatically for every new city.
    """
    if city_in_chroma(city):
        print(f"  📚 '{city}' already in ChromaDB — skipping fetch")
        return

    print(f"  🌐 '{city}' not in ChromaDB → fetching from Wikivoyage...")
    text = _fetch_wikivoyage(city)

    if not text:
        print(f"  ⚠️ Wikivoyage returned no content → trying Wikipedia...")
        text = _fetch_wikipedia_summary(city)

    if not text:
        print(f"  ❌ No data found for '{city}' — ChromaDB unchanged")
        return

    doc = Document(
        page_content=f"[{city}]\n{text}",
        metadata={"source": "wikivoyage", "city": city}
    )
    chunks = _rag_splitter.split_documents([doc])
    chroma_db.add_documents(chunks)
    _chroma_cities_cache.add(city)
    print(f"  ✅ Added {len(chunks)} chunks for '{city}' to ChromaDB")


MANUAL_GRAPH_SCHEMA = """
Node labels and properties:
- City: name
- Neighbourhood: name, description
- Attraction: name, category, free, cost, open_days, description
- Hotel: name, price
- Flight: airline, price, origin, date

Relationships:
- (Attraction)-[:LOCATED_IN]->(City)
- (Attraction)-[:LOCATED_IN]->(Neighbourhood)
- (Neighbourhood)-[:PART_OF]->(City)
- (Neighbourhood)-[:NEAR_TO]->(Neighbourhood)
- (Hotel)-[:LOCATED_IN]->(City)
- (Flight)-[:FLIES_TO]->(City)

Notes:
- open_days is a list: ["Monday","Tuesday",...,"Sunday"]
- category: gallery, museum, monument, church, park, viewpoint, landmark, attraction
- free is boolean; cost is integer PLN
"""


def run_nl_graph_query(user_question: str, city: str) -> tuple[str, str]:
    """Translates a natural language question to Cypher and executes it on Neo4j."""
    cypher_prompt = f"""You are a Neo4j Cypher expert. Generate a Cypher query to answer:

"{user_question}"
City context: {city}

IMPORTANT: "{city}" is a CITY (travel destination), NOT a neighbourhood.
Do NOT confuse city names with neighbourhood names in your query.

Graph schema:
{MANUAL_GRAPH_SCHEMA}

Rules:
- Use MATCH/WHERE/RETURN only — NO CREATE, DELETE, SET, MERGE, REMOVE
- For day filter: WHERE 'Sunday' IN a.open_days  (use English day name)
- For free: WHERE a.free = true
- For category: WHERE a.category = 'gallery'
- For neighbourhood: MATCH (a:Attraction)-[:LOCATED_IN]->(nb:Neighbourhood {{name: 'X'}})
- For NEAR_TO: MATCH (a)-[:LOCATED_IN]->(nb1)-[:NEAR_TO]->(nb2 {{name: 'X'}})
- RETURN a.name as name, a.description as description, a.cost as cost, a.free as free, a.category as category
- LIMIT 10

Return ONLY the Cypher query, nothing else."""

    cypher_response = llm.invoke(cypher_prompt)
    cypher = cypher_response.content.strip()
    for marker in ["```cypher", "```"]:
        if marker in cypher:
            cypher = cypher.split(marker)[-1].split("```")[0].strip()
            break

    try:
        with driver.session() as session:
            rows = [dict(r) for r in session.run(cypher)]
    except Exception as e:
        return f"Error executing Cypher query: {e}", cypher

    if not rows:
        return f"No results found for this query in {city}.", cypher

    format_prompt = f"""Answer in English based on these Neo4j results:

Question: "{user_question}"
Results: {rows[:10]}

List the places with: name, short description, cost ('free' if free=true or cost=0).
IMPORTANT: Use ONLY the data provided above. Do NOT add any places not in the results.
If a field is missing, write 'no information available' — never invent details.
End with: "📌 Source: Neo4j Graph — {city}" """

    # Use llm_stream so astream_events captures token-by-token events for GraphQuery node
    return llm_stream.invoke(format_prompt).content, cypher


print("✅ GraphCypher engine ready")


def get_best_context(query: str, k: int = _MQR_FINAL_K) -> tuple[str, list[str]]:
    """
    Returns up to k RAG chunks using _FilteredMultiQueryRetriever + MMR.

    How it works:
      1. The LLM generates 3 alternative phrasings of `query`.
      2. _is_real_query() filters preamble / numbered-list lines before
         they reach ChromaDB
      3. Each filtered phrasing (+ the original) is run through MMR retrieval.
      4. All results are merged and deduplicated by page content.
      5. Returns up to _MQR_FINAL_K=12 chunks

    Note: vector search always returns the k nearest neighbours even
    for nonsense queries.  In practice this is a non-issue because nonsense
    messages are labelled 'off_topic' by the intent classifier before
    get_best_context is ever called.

    Falls back to plain MMR → similarity search on any error.
    """
    try:
        raw_docs = _multi_query_retriever.invoke(query)
        docs = raw_docs[:k]
        if not docs:
            return "", []
        context = "\n---\n".join(doc.page_content for doc in docs)
        sources = [f"Wikivoyage (MultiQuery): {doc.page_content[:120]}..." for doc in docs]
        print(f"  📚 MultiQueryRetriever: {len(docs)} unique chunks for '{query[:50]}'")
        return context, sources

    except Exception as e:
        print(f"  ⚠️ MultiQueryRetriever error: {e} — falling back to MMR")

    # ── Fallback 1: plain MMR ────────────────────────────────────────────────
    try:
        results = chroma_db.max_marginal_relevance_search(query, k=_RAG_K, fetch_k=_RAG_FETCH_K)
        if not results:
            return "", []
        context = "\n---\n".join(doc.page_content for doc in results)
        sources = [f"Wikivoyage (MMR): {doc.page_content[:120]}..." for doc in results]
        return context, sources
    except Exception as e:
        print(f"  ⚠️ MMR fallback error: {e} — trying similarity search")

    # ── Fallback 2: cosine similarity search ─────────────────────────────────
    try:
        fallback = chroma_db.similarity_search_with_score(query, k=_RAG_K)
        context = "\n---\n".join(doc.page_content for doc, _ in fallback)
        sources = [
            f"Wikivoyage ({round((1 - score) * 100)}%): {doc.page_content[:120]}..."
            for doc, score in fallback
        ]
        return context, sources
    except Exception as e:
        print(f"  ⚠️ Similarity search fallback error: {e}")
        return "", []


class TripState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], operator.add]
    city: str
    budget: float
    duration: int
    departure_date: str
    research_data: dict
    flights_hotels: dict
    weather_data: dict
    final_plan: str
    conversation_history: list
    current_plan: str
    intent: str
    user_message: str



def _append_history(state: TripState, content: str) -> list[dict]:
    """Appends an assistant turn to the conversation history and returns the updated list."""
    history = list(state.get("conversation_history", []))
    history.append({"role": "assistant", "content": content})
    return history


def _ensure_city_in_graph(city: str) -> None:
    """Ensures the city node exists in Neo4j, enriching with LLM data when absent."""
    if not city_exists_in_graph(city):
        print(f"  🌍 '{city}' not in graph → enriching...")
        enrich_city_in_graph(city)


def _ensure_city_enriched(city: str) -> None:
    """Like _ensure_city_in_graph, but also verifies neighbourhood data is present."""
    if not city_exists_in_graph(city) or not city_has_neighbourhoods(city):
        print(f"  🌍 '{city}' needs enrichment → running graph enrichment...")
        enrich_city_in_graph(city)


def _keyword_intent(user_msg: str, has_plan: bool) -> str | None:
    """
    Deterministic intent detection via keyword matching.
    Runs *before* the LLM call to reduce latency and avoid small-model errors.
    Returns the matched intent string, or None if no confident match is found.
    """
    msg = user_msg.lower()

    if any(kw in msg for kw in _KW_INJECTION):
        print(f"🛡️ [Injection Guard] Blocked prompt injection attempt: '{user_msg[:60]}'")
        return "off_topic"
    if any(kw in msg for kw in _KW_NEW_TRIP):
        print(f"🗺️ [Intent Classifier] Forcing 'new_trip' — matched keyword in '{user_msg[:60]}'")
        return "new_trip"
    if any(kw in msg for kw in _KW_JUSTIFY):
        return "justify"
    if any(kw in msg for kw in _KW_GRAPH):
        return "graph_query"
    if any(kw in msg for kw in _KW_FLIGHT):
        return "flight_search"
    if any(kw in msg for kw in _KW_HOTEL):
        return "hotel_search"
    if any(kw in msg for kw in _KW_ATTRACTIONS):
        return "attractions"

    if has_plan:
        if any(kw in msg for kw in _KW_RECALL):
            return "justify"
        if any(kw in msg for kw in _KW_REFINE):
            return "refine"

    if any(kw in msg for kw in _KW_WEATHER):
        return "weather"
    if any(kw in msg for kw in _KW_OFF_TOPIC):
        return "off_topic"

    return None


def intent_classifier(state: TripState):
    """Classifies intent: new_trip | refine | flight_search | hotel_search | attractions | justify | off_topic | graph_query"""
    user_msg = state.get("user_message", "")
    current_plan = state.get("current_plan", "")

    keyword_intent = _keyword_intent(user_msg, bool(current_plan))
    if keyword_intent:
        print(f"🧭 [Intent Classifier] '{keyword_intent}' ← KEYWORD ← '{user_msg[:60]}'")
        return {"intent": keyword_intent}

    prompt = f"""Classify this travel assistant message into exactly ONE of these intents.

'flight_search' = user wants to search/find flights only
'hotel_search' = user wants to search/find hotels only
'attractions' = user wants to see attractions/things to do in a city
'justify' = user asks WHY something was recommended
'graph_query' = relational question about places near each other, opening days, neighbourhood-based queries
'refine' = user wants to MODIFY an existing travel plan (only if plan exists)
'new_trip' = user wants a complete travel plan / itinerary
'off_topic' = message has NOTHING to do with travel, trips, flights, hotels, cities or tourism

Current plan exists: {"YES" if current_plan else "NO"}
User message: "{user_msg}"

Reply with ONLY one word from the list above."""

    response = llm.invoke(prompt)
    raw = response.content.strip().lower()

    valid = {"flight_search", "hotel_search", "attractions", "justify", "refine",
             "new_trip", "off_topic", "graph_query", "weather"}
    intent = next((i for i in valid if i in raw), None)

    if not intent:
        intent = "refine" if current_plan else "new_trip"

    print(f"🧭 [Intent Classifier] '{intent}' ← '{user_msg[:60]}'")
    return {"intent": intent}


def graph_query_agent(state: TripState):
    """Agent for relational graph queries — translates NL to Cypher and executes on Neo4j."""
    user_msg = state.get("user_message", "")
    city = state.get("city", "Lisbon")
    print(f"🔗 [GraphQuery Agent] Query: '{user_msg[:60]}' | city: {city}")

    _ensure_city_enriched(city)

    graph_rag_sources = [f"Neo4j Graph — {city}"]
    try:
        answer, cypher_query = run_nl_graph_query(user_msg, city)
        result_text = f"🔍 **Neo4j Graph Query Result:**\n\n{answer}"
        if cypher_query:
            # Cypher goes to the sources panel, not inline in the streamed response
            graph_rag_sources.insert(0, f"📊 Cypher: `{cypher_query.strip()[:200]}`")
    except Exception as e:
        print(f"  ⚠️ run_nl_graph_query error: {e} → fallback")
        result_text = _graph_query_fallback(user_msg, city)

    history = _append_history(state, result_text)
    return {
        "final_plan": result_text,
        "current_plan": state.get("current_plan", ""),
        "conversation_history": history,
        "research_data": {"attractions": [], "context": "", "rag_sources": graph_rag_sources},
    }


def _graph_query_fallback(user_msg: str, city: str) -> str:
    """Fallback with direct Cypher queries for common patterns."""
    msg_lower = user_msg.lower()

    with driver.session() as session:
        # Fetch actual neighbourhoods for the city from the database
        nb_result = session.run(
            "MATCH (nb:Neighbourhood)-[:PART_OF]->(c:City {name: $city}) RETURN nb.name as name",
            city=city
        )
        neighbourhoods = [r["name"] for r in nb_result]
        found_neighbourhood = next((n for n in neighbourhoods if n.lower() in msg_lower), None)

        day_map = {
            "monday": "Monday", "tuesday": "Tuesday", "wednesday": "Wednesday",
            "thursday": "Thursday", "friday": "Friday", "saturday": "Saturday", "sunday": "Sunday",
        }
        found_day = next((day_map[k] for k in day_map if k in msg_lower), None)
        wants_free = "free" in msg_lower or "free entry" in msg_lower

        category_map = {
            "gallery": "gallery", "galleries": "gallery",
            "museum": "museum", "museums": "museum",
            "park": "park", "church": "church", "monument": "monument",
        }
        found_category = next((category_map[k] for k in category_map if k in msg_lower), None)

        # Parameterized Cypher — avoids injection from names with apostrophes
        params: dict = {}
        conditions = []

        if found_neighbourhood:
            cypher = "MATCH (a:Attraction)-[:LOCATED_IN|NEAR_TO*1..2]->(nb:Neighbourhood {name: $nb_name})"
            params["nb_name"] = found_neighbourhood
        elif city:
            cypher = "MATCH (a:Attraction)-[:LOCATED_IN]->(c:City {name: $city_name})"
            params["city_name"] = city
        else:
            cypher = "MATCH (a:Attraction)"

        if found_category:
            conditions.append("a.category = $category")
            params["category"] = found_category
        if wants_free:
            conditions.append("a.free = true")
        if found_day:
            conditions.append("$day IN a.open_days")
            params["day"] = found_day

        if conditions:
            cypher += " WHERE " + " AND ".join(conditions)
        cypher += " RETURN a.name as name, a.description as desc, a.cost as cost, a.open_days as days LIMIT 15"

        result = session.run(cypher, **params)
        rows = list(result)

        if not rows:
            return f"No results found for query '{user_msg}'. Make sure you're asking about {city}."

        lines = [f"🔍 **Places found** (Neo4j query):\n"]
        for r in rows[:8]:
            free_tag = " 🆓" if not r["cost"] or r["cost"] == 0 else f" ({r['cost']} PLN)"
            days = ", ".join(r["days"][:3]) + "..." if r["days"] and len(r["days"]) > 3 else (", ".join(r["days"]) if r["days"] else "")
            lines.append(f"• **{r['name']}**{free_tag} — {r['desc'] or ''}")
            if days:
                lines.append(f"  🕐 Open: {days}")

        if found_neighbourhood:
            lines.append(f"\n📍 Area: {found_neighbourhood}")
        lines.append(f"\n📌 Source: Neo4j Graph\n```\nCypher: {cypher[:200]} | params: {params}\n```")
        return "\n".join(lines)


def off_topic_agent(state: TripState):
    """Agent that refuses to answer questions unrelated to travel."""
    user_msg = state.get("user_message", "")
    current_plan = state.get("current_plan", "")
    print(f"🚫 [Off-Topic Agent] Rejecting query: '{user_msg[:60]}'")

    prompt = f"""You are Horyzonty, a travel assistant. Always reply in English.
The user asked something unrelated to travel.

Query: "{user_msg}"
Current travel plan exists: {"YES" if current_plan else "NO"}

Respond with light humour, as if you're a passionate traveller puzzled by non-travel questions.
- Politely decline in 1–2 sentences
- Remind the user you specialise in travel
- Suggest what you can help with (trip planning, flights, hotels, attractions)
- If a plan exists, refer to it briefly"""

    response = llm_stream.invoke(prompt)
    result = response.content

    history = _append_history(state, result)
    return {"final_plan": result, "current_plan": state.get("current_plan", ""), "conversation_history": history,
            "research_data": {}, "flights_hotels": {}}


def weather_agent(state: TripState):
    """Fetches and formats a weather forecast for the destination city."""
    city = state.get("city", "Lisbon")
    duration = state.get("duration", 3)
    current_plan = state.get("current_plan", "")
    print(f"🌤️ [Weather Agent] Fetching forecast for: {city} ({duration} days)")

    weather = get_weather(city, days=max(duration, 3))
    forecast = weather.get("forecast", [])
    source = weather.get("source", "OpenWeatherMap")
    is_mock = "Demo forecast" in source or "Mock" in source

    if not forecast:
        result = f"⚠️ Couldn't fetch weather forecast for **{city}** — please try again later."
    else:
        mock_banner = (
            f"\n> ⚠️ *This is a simulated forecast — real data unavailable ({source}). "
            f"Add a valid `OPENWEATHERMAP_API_KEY` to `.env` for live forecasts.*\n"
            if is_mock else ""
        )

        lines = [f"🌤️ **Weather Forecast — {city}:**{mock_banner}\n"]

        for i, day in enumerate(forecast[:max(duration, 3)], 1):
            level = day.get("outdoor_level", "perfect" if day.get("outdoor_friendly") else "rainy")
            hint = _WEATHER_LEVEL_HINT[level]
            lines.append(
                f"**Day {i} ({day['date']}):** {_WEATHER_LEVEL_ICON[level]} "
                f"{day['description'].title()}, {day['temp_avg']}°C "
                f"| 💧 Rain: {day['rain_probability']}%{hint}"
            )

        rainy_days  = [d for d in forecast[:duration] if d.get("outdoor_level","good") == "rainy"]
        mixed_days  = [d for d in forecast[:duration] if d.get("outdoor_level","good") == "mixed"]
        good_days   = [d for d in forecast[:duration] if d.get("outdoor_level","good") in ("perfect","good")]

        if not good_days and not mixed_days:
            lines.append(
                f"\n⚠️ **All days have high rain probability (≥70%).**\n"
                f"Consider packing waterproof gear or replacing outdoor activities with museums and indoor experiences."
            )
        elif rainy_days or mixed_days:
            parts = []
            if good_days:
                parts.append(f"✅ {len(good_days)} day(s) great for outdoor sightseeing")
            if mixed_days:
                parts.append(f"⛅ {len(mixed_days)} day(s) mixed — outdoor in morning OK")
            if rainy_days:
                parts.append(f"🌧️ {len(rainy_days)} day(s) rainy — indoor only")
            lines.append("\n" + " | ".join(parts))
        else:
            if is_mock:
                lines.append(
                    f"\n🔵 *Simulated forecast shows no rainy days — "
                    f"verify with real data once OpenWeatherMap key is active.*"
                )
            else:
                lines.append(f"\n✅ All days look suitable for outdoor activities!")

        # If a plan exists, offer weather-based adjustments
        if current_plan and (rainy_days or mixed_days):
            problem_day_nums = [i + 1 for i, d in enumerate(forecast[:duration])
                                if d.get("outdoor_level", "good") in ("rainy", "mixed")]
            if problem_day_nums:
                lines.append(
                    f"\n💡 Based on the forecast, I can adjust your plan to move outdoor activities away from "
                    f"Day {', Day '.join(map(str, problem_day_nums))}. Just ask: **\"adjust plan for weather\"**."
                )

        lines.append(f"\n📌 Source: {source}")
        result = "\n".join(lines)

    history = _append_history(state, result)
    return {
        "final_plan": result,
        "current_plan": current_plan,
        "conversation_history": history,
        "weather_data": weather,
        "research_data": {"rag_sources": [f"🌤️ Weather: {source} — {city}"]},
    }


def route_by_intent(state: TripState) -> str:
    """Routes the graph based on detected intent."""
    return state.get("intent", "new_trip")


def flight_search_agent(state: TripState):
    """Agent for searching flights only."""
    city = state["city"]
    budget = state.get("budget", 9999)
    departure_date = state.get("departure_date", "")
    print(f"✈️ [Flight Search Agent] Searching flights to: {city}, date: {departure_date or 'any'}")

    _ensure_city_in_graph(city)

    flights = search_flights(city, departure_date=departure_date or None)
    if not flights:
        result = f"Sorry, no flights found to **{city}**."
    else:
        source_tag = " *(Amadeus live)*" if flights[0].get("source") == "Amadeus" else " *(Neo4j)*"
        dep_date_label = f" on {flights[0].get('date', departure_date)}" if flights else ""
        lines = [f"✈️ **Available flights WAW → {city}{dep_date_label}:**{source_tag}\n"]
        for i, f in enumerate(flights[:5], 1):
            in_budget = " ✅" if f['price'] <= budget else ""
            dep = f" {f['departure']}→{f['arrival']}" if f.get("departure") else ""
            dur = f" ({f['duration']})" if f.get("duration") else ""
            book = f" [Book ↗]({f['booking_url']})" if f.get("booking_url") else ""
            lines.append(f"{i}. **{f['airline']}** — {f['price']} PLN{dep}{dur}{in_budget}{book}")
        result = "\n".join(lines)

    history = _append_history(state, result)
    return {
        "final_plan": result,
        "conversation_history": history,
        "flights_hotels": {"flights_data": flights, "budget": budget},
    }


def hotel_search_agent(state: TripState):
    """Agent for searching hotels only."""
    city = state["city"]
    budget = state.get("budget", 9999)
    print(f"🏨 [Hotel Search Agent] Searching hotels in: {city}")

    _ensure_city_in_graph(city)

    hotels = search_hotels(city)
    if not hotels:
        result = f"Sorry, no hotels found in **{city}**."
    else:
        lines = [f"🏨 **Available hotels in {city}:**\n"]
        for i, h in enumerate(hotels[:5], 1):
            in_budget = " ✅" if h['price'] <= budget else ""
            lines.append(f"{i}. **{h['name']}** — {h['price']} PLN/night{in_budget}")
        result = "\n".join(lines)

    history = _append_history(state, result)
    return {
        "final_plan": result,
        "conversation_history": history,
        "flights_hotels": {"hotels_data": hotels, "budget": budget},
    }


def attractions_agent(state: TripState):
    """Agent for showing attractions in a city — from database only."""
    city = state["city"]
    print(f"🗺️ [Attractions Agent] Looking for attractions in: {city}")

    _ensure_city_in_graph(city)
    ensure_city_in_chroma(city)

    with driver.session() as session:
        result = session.run(
            """MATCH (a:Attraction)-[:LOCATED_IN]->(c:City {name: $city})
               RETURN a.name as name, a.category as category, a.cost as cost
               ORDER BY a.cost ASC""",
            city=city
        )
        attractions = [{"name": r["name"], "type": r["category"], "cost": r["cost"]} for r in result]

    rag_context, rag_sources = get_best_context(f"attractions sightseeing {city}", k=3)

    if not attractions:
        result_text = f"Sorry, no attraction data found for {city} in my database."
    else:
        prompt = f"""You are a travel guide. Reply in English.

Describe the tourist attractions in {city} based only on the data below.

ATTRACTIONS FROM DATABASE (describe only these):
{chr(10).join([f"- {a['name']} | type: {a['type']} | admission: {a['cost']} PLN" for a in attractions])}

GUIDE EXCERPTS (context only):
{rag_context}

Rules:
- Describe only the attractions listed above
- If no description is available for a place, write "popular attraction, worth visiting"
- End with: "📌 Data: Neo4j + Wikivoyage" """

        response = llm_stream.invoke(prompt)
        result_text = response.content

    history = _append_history(state, result_text)
    return {
        "final_plan": result_text,
        "conversation_history": history,
        "research_data": {"attractions": [a["name"] for a in attractions], "context": rag_context, "rag_sources": rag_sources}
    }


def justify_agent(state: TripState):
    """Agent for explaining recommendations — cites exact sources."""
    user_msg = state.get("user_message", "")
    current_plan = state.get("current_plan", "")
    city = state["city"]
    print(f"🔍 [Justify Agent] Explaining recommendation for: '{city}' | question: '{user_msg[:50]}'")

    ensure_city_in_chroma(city)

    # --- Data from Neo4j ---
    neo4j_info = []
    with driver.session() as neo_session:
        hotel_rows = list(neo_session.run(
            "MATCH (h:Hotel)-[:LOCATED_IN]->(c:City {name: $city}) RETURN h.name as name, h.price as price",
            city=city
        ))
        neo4j_info += [f"Hotel: {r['name']} ({r['price']} PLN/night)" for r in hotel_rows]
        attr_rows = list(neo_session.run(
            "MATCH (a:Attraction)-[:LOCATED_IN]->(c:City {name: $city}) RETURN a.name as name, a.description as desc, a.category as cat LIMIT 5",
            city=city
        ))
        neo4j_info += [f"Attraction: {r['name']} ({r['cat']}) — {r['desc'] or 'no description'}" for r in attr_rows]
    print(f"  🗃️ Neo4j for '{city}': {len(neo4j_info)} records")

    search_query = current_plan[:300] if current_plan else f"travel hotels attractions {city}"
    rag_results = chroma_db.similarity_search_with_score(search_query, k=5)
    relevant = [
        (doc, score) for doc, score in rag_results
        if city.lower() in doc.page_content.lower() and score <= 1.2
    ]
    if not relevant:
        relevant = rag_results[:3]

    rag_context_for_prompt = "\n\n".join([
        f"📄 Excerpt {i+1} (similarity: {round((1-score)*100)}%):\n\"{doc.page_content[:400]}\""
        for i, (doc, score) in enumerate(relevant)
    ])
    rag_sources = [
        f"(similarity {round((1-score)*100)}%) {doc.page_content[:200]}..."
        for doc, score in relevant
    ]

    neo4j_section = (
        f"\nNEO4J GRAPH DATA for {city}:\n" + "\n".join(neo4j_info)
        if neo4j_info else ""
    )

    if not neo4j_info and not rag_context_for_prompt:
        # Still answer recall questions from the plan itself
        if current_plan:
            recall_prompt = f"""You are a travel assistant. Answer the question using ONLY the plan below.

QUESTION: "{user_msg}"
CURRENT PLAN:
{current_plan[:800]}

Answer briefly and directly. If the answer is not in the plan, say so clearly."""
            try:
                result_text = llm_stream.invoke(recall_prompt).content
            except Exception:
                result_text = "I couldn't find that information in your current plan."
        else:
            result_text = (
                f"No detailed data found to answer that for **{city}**. "
                f"The recommendation was generated from the model's general knowledge."
            )
        sources = []
    else:
        prompt = f"""You are a travel assistant. Reply in English.

The user is asking about their travel plan or why something was recommended.

QUESTION: "{user_msg}"
CURRENT PLAN (excerpt): {current_plan[:600] if current_plan else "none"}
CITY: {city}
{neo4j_section}

KNOWLEDGE BASE EXCERPTS (Wikivoyage/Wikipedia) for {city}:
{rag_context_for_prompt}

Answer:
1. If the question is about budget, duration, city, hotel or flight — answer directly from the plan excerpt above
2. If asking why something was recommended — state the source (Neo4j graph / Wikivoyage / model knowledge)
3. If the hotel/attraction is in Neo4j — include specific data (price, description)
4. If there is a Wikivoyage/Wikipedia excerpt — quote it
5. If no data is available — say so clearly

Do not make up data. Use only what is provided above."""

        response = llm_stream.invoke(prompt)
        result_text = response.content
        sources = (
            [f"Neo4j Graph — {city}: {', '.join(neo4j_info[:3])}"] +
            rag_sources
        )

    history = _append_history(state, result_text)
    return {
        "final_plan": result_text,
        "current_plan": state.get("current_plan", ""),
        "conversation_history": history,
        "research_data": {"attractions": [], "context": "", "rag_sources": sources}
    }


def researcher_agent(state: TripState):
    """Fetches attractions and RAG context for the destination city."""
    city = state["city"]
    print(f"🔍 [Researcher] Searching database for: {city}...")

    _ensure_city_in_graph(city)
    ensure_city_in_chroma(city)

    with driver.session() as session:
        result = session.run(
            """MATCH (a:Attraction)-[:LOCATED_IN]->(c:City {name: $city})
               OPTIONAL MATCH (a)-[:LOCATED_IN]->(nb:Neighbourhood)
               RETURN a.name AS name, a.category AS category, a.cost AS cost,
                      a.free AS free, a.description AS description, nb.name AS neighbourhood
               ORDER BY a.cost ASC""",
            city=city)
        raw_attractions = [dict(r) for r in result]

    # Deduplicate: OPTIONAL MATCH can return multiple rows per attraction
    # when it's linked to more than one neighbourhood
    seen_names: set[str] = set()
    deduped = []
    for r in raw_attractions:
        if r["name"] not in seen_names:
            seen_names.add(r["name"])
            deduped.append(r)
    raw_attractions = deduped

    if not raw_attractions:
        attractions = [f"{city} City Centre", f"{city} Local Attractions"]
        context = f"No detailed information available for {city}."
        rag_sources = []
        attractions_full = []
    else:
        attractions = [r["name"] for r in raw_attractions]
        attractions_full = raw_attractions
        context, rag_sources = get_best_context(f"[{city}] tourist attractions sightseeing what to see", k=5)

    return {"research_data": {
        "attractions": attractions,
        "attractions_full": attractions_full,
        "context": context,
        "rag_sources": rag_sources
    }}


def booking_agent(state: TripState):
    city = state["city"]
    budget = state["budget"]
    departure_date = state.get("departure_date", "")
    print(f"💳 [Booking] Searching flights and hotels to {city}, budget: {budget} PLN, date: {departure_date or 'any'}...")

    all_flights = search_flights(city, departure_date=departure_date or None)
    hotels = search_hotels(city)

    if not all_flights or not hotels:
        return {"flights_hotels": {"error": "No flights or hotels found."}}

    cheapest_hotel = min(hotels, key=lambda x: x['price'])
    hotel_cost = cheapest_hotel['price']
    duration = state.get("duration", 2)
    total_hotel_cost = hotel_cost * duration

    flights_in_budget = [f for f in all_flights if f['price'] + total_hotel_cost <= budget]
    if not flights_in_budget:
        flights_in_budget = sorted(all_flights, key=lambda x: x['price'])[:3]

    selected_flight = flights_in_budget[0]
    total_cost = selected_flight['price'] + total_hotel_cost

    # Only warn when budget was actually specified (guard: > 200 PLN)
    remaining = budget - total_cost
    budget_exceeded = (budget > 200) and (remaining < 0)
    budget_tight = (budget > 200) and (0 <= remaining < 100) and not budget_exceeded
    budget_gap = abs(remaining) if budget_exceeded else 0

    # Cheapest possible total for the alert message (may differ from selected flight)
    cheapest_possible = sorted(all_flights, key=lambda x: x['price'])[0]['price'] + total_hotel_cost

    booking_info = {
        "flight_info": selected_flight,
        "hotel_info": cheapest_hotel,
        "all_flights": all_flights[:5],
        "total_cost": total_cost,
        "remaining_budget": remaining,
        "budget_exceeded": budget_exceeded,
        "budget_tight": budget_tight,
        "budget_gap": round(budget_gap),
        "cheapest_possible": round(cheapest_possible),
    }
    status = "⚠️ OVER BUDGET" if budget_exceeded else ("💛 tight" if budget_tight else "✅ within budget")
    print(f"  {status}: Flight {selected_flight['airline']} {selected_flight['price']} PLN + Hotel {cheapest_hotel['name']} {hotel_cost} PLN/night × {duration} = {total_cost} PLN (budget: {budget} PLN)")
    return {"flights_hotels": booking_info}


def _build_planner_weather_context(
    forecast: list, duration: int, weather_source: str
) -> tuple[str, list[str]]:
    """
    Formats a per-day weather block for the planner prompt.
    Returns (weather_context_str, extra_rag_source_entries).
    """
    if not forecast:
        return "Weather data unavailable — assume good weather for all days.", []

    is_mock = "Demo forecast" in weather_source or "Mock" in weather_source
    mock_note = " *(simulated — add OPENWEATHERMAP_API_KEY for real data)*" if is_mock else ""

    lines = []
    for i, day in enumerate(forecast[:duration], 1):
        level = day.get("outdoor_level", "perfect" if day.get("outdoor_friendly") else "rainy")
        lines.append(
            f"Day {i} ({day['date']}): {_WEATHER_LEVEL_ICON[level]} "
            f"{day['description'].title()}, {day['temp_avg']}°C, "
            f"Rain: {day['rain_probability']}% — {_WEATHER_LEVEL_INSTRUCTION[level]}"
        )

    weather_context = (
        f"WEATHER FORECAST{mock_note} (MANDATORY — follow scheduling instructions per day):\n"
        + "\n".join(lines)
    )
    return weather_context, [f"🌤️ Weather ({weather_source}){mock_note}"]


def _format_planner_attractions(attractions_full: list, verified_attractions: list) -> str:
    """Formats the attractions list for insertion into the planner prompt."""
    if attractions_full:
        return "\n".join([
            f"- {a['name']} | {a.get('category', '?')} | "
            f"{'free' if a.get('free') else str(a.get('cost', '?')) + ' PLN'} | "
            f"area: {a.get('neighbourhood') or 'city centre'} | "
            f"{a.get('description') or 'popular attraction'}"
            for a in attractions_full
        ])
    return "\n".join([f"- {a}" for a in verified_attractions])


def _split_remaining_budget(remaining_budget: float, duration: int) -> tuple[int, int]:
    """
    Splits remaining budget into food-per-day and activities totals.
    Returns (food_per_day, activities_budget).
    """
    usable = max(0, remaining_budget)
    food_per_day = min(120, max(60, int(usable * 0.4 / max(duration, 1))))
    activities_budget = max(0, usable - food_per_day * duration)
    return food_per_day, int(activities_budget)


def _build_budget_banner(booking: dict, budget: float) -> str:
    """Returns a markdown budget warning banner, or an empty string when budget is fine."""
    if booking.get("budget_exceeded"):
        cheapest = booking.get("cheapest_possible", 0)
        gap = booking.get("budget_gap", 0)
        return (
            f"> ⚠️ **Budget Alert** — The cheapest available option "
            f"(flight + hotel) costs **{int(cheapest):,} PLN**, "
            f"which is **{int(gap):,} PLN over your budget** of {int(budget):,} PLN.\n"
            f"> The plan below uses the most affordable flights and hotel found. "
            f"Consider increasing your budget or shortening your trip.\n\n"
        )
    if booking.get("budget_tight"):
        remaining = booking.get("remaining_budget", 0)
        return (
            f"> 💡 **Heads up** — After flights and hotel you have only "
            f"**{max(0, int(remaining)):,} PLN** left for food and activities. "
            f"Consider packing a lunch or sticking to free attractions.\n\n"
        )
    return ""


def planner_agent(state: TripState):
    """Generates a detailed, weather-aware travel itinerary with an hourly schedule."""
    print("📅 [Planner] Generating detailed plan...")

    research = state.get("research_data", {})
    booking = state.get("flights_hotels", {})
    budget = state["budget"]
    duration = state.get("duration", 2)
    city = state["city"]

    if "error" in booking:
        plan = f"Sorry, no flight/hotel found within budget {budget} PLN. {booking['error']}"
        return {"final_plan": plan, "current_plan": plan}

    verified_attractions = research.get('attractions', [])
    attractions_full = research.get('attractions_full', [])
    rag_context = research.get('context', '')
    rag_sources = research.get('rag_sources', [])
    flight_info = booking.get('flight_info', {})
    hotel_info = booking.get('hotel_info', {})

    print(f"  🌤️ Fetching weather for {city} ({duration} days)...")
    weather = get_weather(city, days=duration + 1)
    weather_context, weather_sources = _build_planner_weather_context(
        weather.get("forecast", []), duration, weather.get("source", "OpenWeatherMap")
    )
    rag_sources = rag_sources + weather_sources

    attractions_detail = _format_planner_attractions(attractions_full, verified_attractions)
    food_per_day, activities_budget = _split_remaining_budget(
        booking.get('remaining_budget', 0), duration
    )
    nights_label = "night" if duration == 1 else "nights"

    prompt = f"""You are a travel expert. Reply in English.
Create a detailed travel itinerary with an hourly schedule for each day.

CITY: {city}
TRIP LENGTH: {duration} {"day" if duration == 1 else "days"}

BOOKINGS (use exactly these):
- ✈️ Flight: {flight_info.get('airline', '?')} — {flight_info.get('price', '?')} PLN
- 🏨 Hotel: {hotel_info.get('name', '?')} — {hotel_info.get('price', '?')} PLN/night
- 💰 Activities budget: ~{int(activities_budget)} PLN | food budget: ~{food_per_day} PLN/day

{weather_context}

ATTRACTIONS FROM DATABASE (use only these, do not add your own):
{attractions_detail}

GUIDE CONTEXT (for descriptions only, does not add new places):
{rag_context[:1500] if rag_context else "none"}

GENERATE PLAN FOLLOWING THIS SCHEMA — EVERY FIELD IS MANDATORY:

## ✈️ Travel & Accommodation
- Flight: [airline] — [price] PLN
- Hotel: [name] — [price] PLN/night
- Tip: how to get from airport to hotel (metro/bus/taxi, ~cost)

{"".join([f"""
## 📅 Day {i} — [give the day a title e.g. "Old Town & History"]
[One line: weather summary for this day from the forecast e.g. "☀️ Sunny, 22°C — great day for outdoor sightseeing" OR "🌧️ Rainy, 15°C — indoor focus today"]

**🌅 Morning (9:00–12:00)**
- 9:00 → [attraction from list — OUTDOOR only if weather allows]: [2–3 sentences description, cost]
- 10:30 → [next attraction from list]: [description]

**☀️ Midday (12:00–14:00)**
- Lunch nearby: [type of restaurant, recommended local dish, estimated cost ~{food_per_day//2} PLN]

**🌇 Afternoon (14:00–18:00)**
- 14:00 → [attraction from list]: [description, cost]
- 16:00 → [attraction or activity from list]: [description]

**🌆 Evening (18:00–21:00)**
- Dinner: [type of restaurant, local cuisine, estimated cost ~{food_per_day//2} PLN]
- Optional: [evening walk / viewpoint / activity from list]
""" for i in range(1, duration + 1)])}

## 💰 Cost Summary
| Item | Cost |
|------|------|
| Flight | {flight_info.get('price', '?')} PLN |
| Hotel ({duration} {nights_label}) | {int(hotel_info.get('price', 0)) * duration} PLN |
| Food ({duration} days) | ~{food_per_day * duration} PLN |
| Activities & entry fees | ~{int(activities_budget)} PLN |
| **TOTAL** | ~{int(flight_info.get('price', 0) + hotel_info.get('price', 0) * duration + food_per_day * duration + activities_budget)} PLN |

## 💡 Practical Tips for {city}
- [3–4 specific, useful tips: public transport, currency, customs, what to pack]

📌 Sources: Neo4j database + Wikivoyage

Rules:
- Use only attractions from the provided list
- Every attraction must have a time and a real description
- The schedule must be logical (travel time, fatigue)"""

    response = llm_stream.invoke(prompt)
    plan = _build_budget_banner(booking, budget) + str(response.content)

    history = _append_history(state, f"[Plan for {city}]\n{plan}")
    return {
        "final_plan": plan,
        "current_plan": plan,
        "conversation_history": history,
        "weather_data": weather,
        "research_data": {**research, "rag_sources": rag_sources},
    }


def refine_agent(state: TripState):
    """
    Modifies an EXISTING plan with surgical, targeted edits.
    Architecture:
      1. Guard — bail out immediately if no plan exists
      2. Simple YES/NO validation (avoids fragile JSON parsing)
      3. Surgical edit prompt — model is confined to changing ONE element
    """
    print("✏️ [Refine Agent] Processing modification request...")

    user_msg = state.get("user_message", "")
    current_plan = state.get("current_plan", "")
    history = list(state.get("conversation_history", []))
    budget = state.get("budget", 2000)
    city = state.get("city", "Lisbon")

    if not current_plan:
        response_text = (
            "⚠️ No active plan to modify. Please generate a trip plan first — "
            "e.g. *\"plan 3 days in Lisbon for 2000 PLN\"*"
        )
        history.append({"role": "assistant", "content": response_text})
        return {"final_plan": response_text, "current_plan": "", "conversation_history": history}

    # YES/NO validation — more reliable than JSON parsing with small models
    plan_preview = current_plan[:600]
    validation_prompt = f"""Does the travel plan below contain something related to the user's change request?
Answer with exactly one word: YES or NO.

Plan (excerpt): {plan_preview}
Change request: "{user_msg}"

Answer:"""

    try:
        val_raw = llm.invoke(validation_prompt).content.strip().upper()
        # Accept any response that starts with Y as YES
        is_valid = val_raw.startswith("Y") or "YES" in val_raw[:10]
        print(f"  🔎 Validation: {'VALID' if is_valid else 'INVALID'} (model said: '{val_raw[:20]}')")
    except Exception as e:
        print(f"  ⚠️ Validation error ({e}) — assuming valid")
        is_valid = True

    if not is_valid:
        whats_in_plan_prompt = f"""List the main elements of this travel plan in ONE line (hotel name, flight, day activities).
Plan: {plan_preview}
One-line summary:"""
        try:
            plan_summary = llm.invoke(whats_in_plan_prompt).content.strip()
        except Exception:
            plan_summary = "flights, hotel, and daily activities"

        response_text = (
            f"⚠️ I couldn't find that element in your current plan.\n\n"
            f"📋 Your plan currently includes: {plan_summary}\n\n"
            f"What would you like to change? You can ask to:\n"
            f"- Replace the hotel / make it cheaper\n"
            f"- Remove or swap an activity on a specific day\n"
            f"- Change the flight airline"
        )
        history.append({"role": "assistant", "content": response_text})
        return {
            "final_plan": current_plan,
            "current_plan": current_plan,
            "conversation_history": history,
        }

    # Full plan passed without truncation so model sees all sections
    modify_prompt = f"""You are a travel plan editor. Apply ONE surgical change to the plan below.

CURRENT PLAN:
{current_plan}

CHANGE REQUEST: "{user_msg}"

STRICT RULES — follow exactly:
1. Identify the SINGLE element the user wants to change (hotel / flight / one activity / one day section)
2. Change ONLY that element — leave ALL other text word-for-word identical
3. Do NOT rewrite, reformat, or summarise other sections
4. If user says "cheaper hotel" → update ONLY the hotel line and cost summary
5. If user says "remove the museum" → delete only that activity line
6. If user says "change day 2 afternoon" → edit ONLY that time block in Day 2
7. Begin your response with this marker on its own line:
   ✏️ Changed: [old element] → [new element]
8. Then output the COMPLETE updated plan with that single change applied

Budget context: {budget} PLN total | City: {city}"""

    print(f"  ✂️ Applying surgical edit: '{user_msg[:60]}'")
    response = llm_stream.invoke(modify_prompt)
    refined_plan = response.content

    history.append({"role": "assistant", "content": refined_plan})
    return {
        "final_plan": refined_plan,
        "current_plan": refined_plan,
        "conversation_history": history,
    }


workflow = StateGraph(TripState)

workflow.add_node("IntentClassifier", intent_classifier)
workflow.add_node("Researcher", researcher_agent)
workflow.add_node("Booking", booking_agent)
workflow.add_node("Planner", planner_agent)
workflow.add_node("Refine", refine_agent)
workflow.add_node("FlightSearch", flight_search_agent)
workflow.add_node("HotelSearch", hotel_search_agent)
workflow.add_node("Attractions", attractions_agent)
workflow.add_node("Justify", justify_agent)
workflow.add_node("GraphQuery", graph_query_agent)
workflow.add_node("Weather", weather_agent)
workflow.add_node("OffTopic", off_topic_agent)

workflow.set_entry_point("IntentClassifier")

workflow.add_conditional_edges(
    "IntentClassifier",
    route_by_intent,
    {
        "new_trip":      "Researcher",
        "refine":        "Refine",
        "flight_search": "FlightSearch",
        "hotel_search":  "HotelSearch",
        "attractions":   "Attractions",
        "justify":       "Justify",
        "graph_query":   "GraphQuery",
        "weather":       "Weather",
        "off_topic":     "OffTopic",
    }
)

workflow.add_edge("Researcher", "Booking")
workflow.add_edge("Booking", "Planner")
workflow.add_edge("Planner", END)
workflow.add_edge("Refine", END)
workflow.add_edge("FlightSearch", END)
workflow.add_edge("HotelSearch", END)
workflow.add_edge("Attractions", END)
workflow.add_edge("Justify", END)
workflow.add_edge("GraphQuery", END)
workflow.add_edge("Weather", END)
workflow.add_edge("OffTopic", END)

app_graph = workflow.compile()

if __name__ == "__main__":
    print("🚀 Testing LangGraph Orchestrator...")
    result = app_graph.invoke({
        "messages": [], "city": "Lisbon", "budget": 2000.0, "duration": 2,
        "conversation_history": [], "current_plan": "", "intent": "", "user_message": "plan a trip to Lisbon"
    })
    print("\n✅ PLAN:\n", result['final_plan'])
    driver.close()